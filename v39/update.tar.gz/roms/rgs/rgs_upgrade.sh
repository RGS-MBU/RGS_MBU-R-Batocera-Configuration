#!/bin/bash

BATOVERSION=$(cat /usr/share/batocera/batocera.version|awk {'print $1}')

if [ -f "/userdata/system/rgs.version" ]; then
    CURRENTRGSVERSION=$(cat /userdata/system/rgs.version)
else
    CURRENTRGSVERSION="0"
fi

DISPLAY=:0.0  xterm -fs 40 -maximized -fg white -bg black -fa "DejaVuSansMono" -en UTF-8 -e bash -c "echo 'current RGS version: ${CURRENTRGSVERSION}. Looking for new updates.....' & sleep 1"


LASTRGSVERSION=`curl -s https://raw.githubusercontent.com/RGS-MBU/RGS_MBU-R-Batocera-Configuration/main/v$BATOVERSION/version.txt`

if [ "$CURRENTRGSVERSION" == "$LASTRGSVERSION" ]; then
    DISPLAY=:0.0  xterm -fs 40 -maximized -fg white -bg black -fa "DejaVuSansMono" -en UTF-8 -e bash -c "echo 'No new update is available' & sleep 1"

    exit 0
fi

echo "current installed version: ${CURRENTRGSVERSION}  last RGS version: ${LASTRGSVERSION}"


UPGRADE_SCRIPT="/tmp/rgs_upgrade"
wget -progress=dot:binary --no-check-certificate --no-cache --no-cookies -O $UPGRADE_SCRIPT "https://raw.githubusercontent.com/RGS-MBU/RGS_MBU-R-Batocera-Configuration/main/v$BATOVERSION/rgs_upgrade"
chmod +x $UPGRADE_SCRIPT
DISPLAY=:0.0  xterm -fs 40 -maximized -fg white -bg black -fa "DejaVuSansMono" -en UTF-8 -e $UPGRADE_SCRIPT
rm $UPGRADE_SCRIPT

