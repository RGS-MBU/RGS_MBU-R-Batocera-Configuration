#!/usr/bin/env python

def getGenerator(emulator):
        from customGenerator import CustomGenerator

        return CustomGenerator()


