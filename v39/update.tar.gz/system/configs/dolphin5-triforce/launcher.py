#!/usr/bin/env python

import sys
from sys import exit
from sys import path
python_version = str(sys.version_info[0]) + "."+ str(sys.version_info[1])
path.append("/usr/lib/python" + python_version + "/site-packages/configgen")

### import always needed ###
import argparse
import GeneratorImporter
import signal
import time
from sys import exit
import subprocess
import batoceraFiles
import utils.videoMode as videoMode
import utils.gunsUtils as gunsUtils
import utils.wheelsUtils as wheelsUtils
############################
from utils.logger import get_logger
eslog = get_logger(__name__)
############################


from configgen.emulatorlauncher import *


if __name__ == '__main__':
    proc = None
    signal.signal(signal.SIGINT, signal_handler)
    parser = argparse.ArgumentParser(description='emulator-launcher script')

    maxnbplayers = 8
    for p in range(1, maxnbplayers+1):
        parser.add_argument("-p{}index"     .format(p), help="player{} controller index"            .format(p), type=int, required=False)
        parser.add_argument("-p{}guid"      .format(p), help="player{} controller SDL2 guid"        .format(p), type=str, required=False)
        parser.add_argument("-p{}name"      .format(p), help="player{} controller name"             .format(p), type=str, required=False)
        parser.add_argument("-p{}devicepath".format(p), help="player{} controller device"           .format(p), type=str, required=False)
        parser.add_argument("-p{}nbbuttons" .format(p), help="player{} controller number of buttons".format(p), type=str, required=False)
        parser.add_argument("-p{}nbhats"    .format(p), help="player{} controller number of hats"   .format(p), type=str, required=False)
        parser.add_argument("-p{}nbaxes"    .format(p), help="player{} controller number of axes"   .format(p), type=str, required=False)

    parser.add_argument("-system",         help="select the system to launch", type=str, required=True)
    parser.add_argument("-rom",            help="rom absolute path",           type=str, required=True)
    parser.add_argument("-emulator",       help="force emulator",              type=str, required=False)
    parser.add_argument("-core",           help="force emulator core",         type=str, required=False)
    parser.add_argument("-netplaymode",    help="host/client",                 type=str, required=False)
    parser.add_argument("-netplaypass",    help="enable spectator mode",       type=str, required=False)
    parser.add_argument("-netplayip",      help="remote ip",                   type=str, required=False)
    parser.add_argument("-netplayport",    help="remote port",                 type=str, required=False)
    parser.add_argument("-state_slot",     help="state slot",                  type=str, required=False)
    parser.add_argument("-state_filename", help="state filename",              type=str, required=False)
    parser.add_argument("-autosave",       help="autosave",                    type=str, required=False)
    parser.add_argument("-systemname",     help="system fancy name",           type=str, required=False)
    parser.add_argument("-gameinfoxml",    help="game info xml",               type=str, nargs='?', default='/dev/null', required=False)
    parser.add_argument("-lightgun",       help="configure lightguns",         action="store_true")
    parser.add_argument("-wheel",          help="configure wheel",             action="store_true")

    args = parser.parse_args()
    try:
        exitcode = -1
        exitcode = main(args, maxnbplayers)
    except Exception as e:
        eslog.error("configgen exception: ", exc_info=True)

    time.sleep(1) # this seems to be required so that the gpu memory is restituated and available for es

    exit(exitcode)


