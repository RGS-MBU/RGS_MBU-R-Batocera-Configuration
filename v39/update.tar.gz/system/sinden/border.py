#!/usr/bin/python

import sys
import subprocess
import evdev

###args : systemName, system.config['emulator'], effectiveCore, effectiveRom

if sys.argv[2] != 'windows':
    exit(1)

def getMouseButtons(device):
  caps = device.capabilities()
  caps_keys = caps[evdev.ecodes.EV_KEY]
  caps_filter = [evdev.ecodes.BTN_LEFT, evdev.ecodes.BTN_RIGHT, evdev.ecodes.BTN_MIDDLE, evdev.ecodes.BTN_1, evdev.ecodes.BTN_2, evdev.ecodes.BTN_3, evdev.ecodes.BTN_4, evdev.ecodes.BTN_5, evdev.ecodes.BTN_6, evdev.ecodes.BTN_7, evdev.ecodes.BTN_8]
  caps_intersection = list(set(caps_keys) & set(caps_filter))
  buttons = []
  if evdev.ecodes.BTN_LEFT in caps_intersection:
    buttons.append("left")
  if evdev.ecodes.BTN_RIGHT in caps_intersection:
    buttons.append("right")
  if evdev.ecodes.BTN_MIDDLE in caps_intersection:
    buttons.append("middle")
  if evdev.ecodes.BTN_1 in caps_intersection:
    buttons.append("1")
  if evdev.ecodes.BTN_2 in caps_intersection:
    buttons.append("2")
  if evdev.ecodes.BTN_3 in caps_intersection:
    buttons.append("3")
  if evdev.ecodes.BTN_4 in caps_intersection:
    buttons.append("4")
  if evdev.ecodes.BTN_5 in caps_intersection:
    buttons.append("5")
  if evdev.ecodes.BTN_6 in caps_intersection:
    buttons.append("6")
  if evdev.ecodes.BTN_7 in caps_intersection:
    buttons.append("7")
  if evdev.ecodes.BTN_8 in caps_intersection:
    buttons.append("8")
  return buttons

def getGuns():
    import pyudev
    import re

    guns = {}
    context = pyudev.Context()

    # guns are mouses, just filter on them
    mouses = context.list_devices(subsystem='input')

    # keep only mouses with /dev/iput/eventxx
    mouses_clean = {}
    for mouse in mouses:
        matches = re.match(r"^/dev/input/event([0-9]*)$", str(mouse.device_node))
        if matches != None:
            if ("ID_INPUT_MOUSE" in mouse.properties and mouse.properties["ID_INPUT_MOUSE"]) == '1':
                mouses_clean[int(matches.group(1))] = mouse
    mouses = mouses_clean

    nmouse = 0
    ngun   = 0
    for eventid in sorted(mouses):
        print("found mouse {} at {} with id_mouse={}".format(nmouse, mouses[eventid].device_node, nmouse))
        if "ID_INPUT_GUN" not in mouses[eventid].properties or mouses[eventid].properties["ID_INPUT_GUN"] != "1":
            nmouse = nmouse + 1
            continue

        device = evdev.InputDevice(mouses[eventid].device_node)
        buttons = getMouseButtons(device)

        # retroarch uses mouse indexes into configuration files using ID_INPUT_MOUSE (TOUCHPAD are listed after mouses)
        need_cross   = "ID_INPUT_GUN_NEED_CROSS"   in mouses[eventid].properties and mouses[eventid].properties["ID_INPUT_GUN_NEED_CROSS"]   == '1'
        need_borders = "ID_INPUT_GUN_NEED_BORDERS" in mouses[eventid].properties and mouses[eventid].properties["ID_INPUT_GUN_NEED_BORDERS"] == '1'
        guns[ngun] = {"node": mouses[eventid].device_node, "id_mouse": nmouse, "need_cross": need_cross, "need_borders": need_borders, "name": device.name, "buttons": buttons}
        print("found gun {} at {} with id_mouse={} ({})".format(ngun, mouses[eventid].device_node, nmouse, guns[ngun]["name"]))
        nmouse = nmouse + 1
        ngun = ngun + 1

    if len(guns) == 0:
        print("no gun found")
    return guns


guns = getGuns()
for gun in guns:
    if guns[gun]["need_borders"]:
        if sys.argv[1] == 'gameStart':
            subprocess.Popen('/userdata/system/sinden/border 25', shell=True)

        if sys.argv[1] == 'gameStop':
            subprocess.Popen('killall -9 border', shell=True)




