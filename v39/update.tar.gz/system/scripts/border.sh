#!/bin/bash
/userdata/system/sinden/border.py $1 $2 $3 $4

